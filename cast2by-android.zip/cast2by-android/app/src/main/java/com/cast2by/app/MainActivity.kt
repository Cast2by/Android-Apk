package com.cast2by.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.math.max

class MainActivity : ComponentActivity() {

    companion object {
        private const val START_URL = "https://cast2by.com"
        private val INTERNAL_HOSTS = listOf(
            "cast2by.com",
            "base44.com",
            "base44.app",
            "accounts.google.com"
        )
    }

    private lateinit var container: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var webView: WebView
    private lateinit var insetsController: WindowInsetsControllerCompat

    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var pendingPermissionRequest: PermissionRequest? = null
    private var pendingGeoOrigin: String? = null
    private var pendingGeoCallback: GeolocationPermissions.Callback? = null

    private val fileChooserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            filePathCallback?.onReceiveValue(uris)
            filePathCallback = null
        }

    private val mediaPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            val request = pendingPermissionRequest
            pendingPermissionRequest = null
            if (request != null) {
                val allowed = request.resources.filter { res ->
                    val perms = androidPermissionsFor(res)
                    perms.isNotEmpty() && perms.all { isGranted(it) }
                }.toTypedArray()
                if (allowed.isNotEmpty()) request.grant(allowed) else request.deny()
            }
        }

    private val locationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
            val ok = grants.values.any { it }
            pendingGeoCallback?.invoke(pendingGeoOrigin, ok, false)
            pendingGeoCallback = null
            pendingGeoOrigin = null
        }

    @SuppressLint("SetJavaScriptEnabled")
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Kenardan kenara (edge-to-edge) çiz, çubukların arkası siyah olsun
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.isAppearanceLightStatusBars = false      // açık renk ikonlar
        insetsController.isAppearanceLightNavigationBars = false  // açık renk ikonlar

        container = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        content = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        container.addView(content, matchParent())

        webView = WebView(this).apply { setBackgroundColor(Color.BLACK) }
        content.addView(webView, matchParent())
        setContentView(container)

        // Sistem çubukları ve klavye kadar boşluk bırak, boşluk siyah görünür
        ViewCompat.setOnApplyWindowInsetsListener(content) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, max(bars.bottom, ime.bottom))
            insets
        }

        setupWebView()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> exitFullscreenVideo()
                    webView.canGoBack() -> webView.goBack()
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        if (savedInstanceState == null) webView.loadUrl(START_URL)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(false)
            setGeolocationEnabled(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = "$userAgentString Cast2ByApp"
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        webView.setDownloadListener { url, _, _, _, _ ->
            openExternal(Uri.parse(url))
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView, request: WebResourceRequest
            ): Boolean {
                val uri = request.url
                val scheme = uri.scheme ?: return false
                if (scheme == "http" || scheme == "https") {
                    val host = uri.host ?: return false
                    val internal = INTERNAL_HOSTS.any { host == it || host.endsWith(".$it") }
                    if (internal) return false
                }
                openExternal(uri)
                return true
            }

            override fun onReceivedError(
                view: WebView, request: WebResourceRequest, error: WebResourceError
            ) {
                if (request.isForMainFrame) {
                    view.loadDataWithBaseURL(
                        null,
                        """
                        <html><body style="background:#000;color:#fff;font-family:sans-serif;
                        display:flex;flex-direction:column;align-items:center;justify-content:center;
                        height:100vh;margin:0;text-align:center">
                        <h2>Bağlantı kurulamadı</h2>
                        <p>İnternet bağlantınızı kontrol edin.</p>
                        <a href="$START_URL" style="color:#000;background:#fff;padding:12px 24px;
                        border-radius:8px;text-decoration:none">Tekrar dene</a>
                        </body></html>
                        """.trimIndent(),
                        "text/html", "utf-8", null
                    )
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {

            // Canlı yayın: kamera ve mikrofon
            override fun onPermissionRequest(request: PermissionRequest) {
                val needed = request.resources
                    .flatMap { androidPermissionsFor(it) }
                    .distinct()
                if (needed.isEmpty()) {
                    request.deny()
                    return
                }
                val missing = needed.filter { !isGranted(it) }
                if (missing.isEmpty()) {
                    val allowed = request.resources.filter { androidPermissionsFor(it).isNotEmpty() }
                    request.grant(allowed.toTypedArray())
                } else {
                    pendingPermissionRequest?.deny()
                    pendingPermissionRequest = request
                    mediaPermissionLauncher.launch(missing.toTypedArray())
                }
            }

            // Konum
            override fun onGeolocationPermissionsShowPrompt(
                origin: String, callback: GeolocationPermissions.Callback
            ) {
                if (isGranted(Manifest.permission.ACCESS_FINE_LOCATION) ||
                    isGranted(Manifest.permission.ACCESS_COARSE_LOCATION)
                ) {
                    callback.invoke(origin, true, false)
                } else {
                    pendingGeoOrigin = origin
                    pendingGeoCallback = callback
                    locationPermissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    )
                }
            }

            // Dosya / fotoğraf / video yükleme
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                return try {
                    fileChooserLauncher.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    filePathCallback = null
                    false
                }
            }

            // Tam ekran video
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                container.addView(view, matchParent())
                content.visibility = View.GONE
                insetsController.systemBarsBehavior =
                    WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                insetsController.hide(WindowInsetsCompat.Type.systemBars())
            }

            override fun onHideCustomView() {
                exitFullscreenVideo()
            }
        }
    }

    private fun exitFullscreenVideo() {
        val view = customView ?: return
        container.removeView(view)
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        content.visibility = View.VISIBLE
        insetsController.show(WindowInsetsCompat.Type.systemBars())
    }

    private fun androidPermissionsFor(resource: String): List<String> = when (resource) {
        PermissionRequest.RESOURCE_VIDEO_CAPTURE -> listOf(Manifest.permission.CAMERA)
        PermissionRequest.RESOURCE_AUDIO_CAPTURE -> listOf(Manifest.permission.RECORD_AUDIO)
        else -> emptyList()
    }

    private fun isGranted(permission: String) =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: Exception) {
            // Açacak uygulama yok, yok say
        }
    }

    private fun matchParent() = FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT
    )

    override fun onPause() {
        webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onDestroy() {
        filePathCallback?.onReceiveValue(null)
        webView.destroy()
        super.onDestroy()
    }
}
