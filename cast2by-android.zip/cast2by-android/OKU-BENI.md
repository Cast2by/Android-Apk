# Cast2By Android

cast2by.com sitesini uygulama içinde açan Android projesi.
Alt navigasyon çubuğu ve durum çubuğu siyah, ikonlar açık renk.

## Yol 1: GitHub ile (bilgisayara bir şey kurmadan)
1. github.com'da yeni bir repo aç, bu klasörün içindekileri yükle (.github klasörü dahil).
2. Repo > Actions sekmesi > "APK Derle" > Run workflow.
3. 3-5 dakika sonra bitince çalışmanın altındaki "Cast2By-APK" dosyasını indir, ZIP'ten çıkan .apk'yı telefona kur.

## Yol 2: Android Studio ile
1. Android Studio ile klasörü aç, Gradle sync bitsin.
2. Build > Build APK(s). Dosya: app/build/outputs/apk/debug/app-debug.apk

## Not
- Debug APK telefona kurulur ama Google Play'e yüklenmez. Play için imzalı release (AAB) gerekir.
- Site adresini değiştirmek için MainActivity.kt içindeki START_URL satırını düzenle.
